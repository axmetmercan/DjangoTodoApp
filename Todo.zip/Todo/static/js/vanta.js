VANTA.NET({
    el: "#footer",
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200,
    minWidth: 200,
    scale: 1.00,
    scaleMobile: 1.00,
    points: 20,
    spacing: 18,
    color: 0xff1919,
    backgroundColor: 0x303052
});

VANTA.CLOUDS({
    el: "#deneme-vanta",
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200.00,
    minWidth: 200.00
});